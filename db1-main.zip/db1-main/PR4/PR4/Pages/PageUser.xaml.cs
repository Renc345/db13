﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PR4.Classes;
using Excel = Microsoft.Office.Interop.Excel;


namespace PR4.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageUser.xaml
    /// </summary>
    public partial class PageUser : Page
    {
        public PageUser()
        {
            InitializeComponent();
            DGridUsers.ItemsSource = universityEntities.GetContext().Group.ToList();
        }
        private void btnEdit_Click(object sender, RoutedEventArgs e)
        //Редактирование пользователей
        {
            ClassFrame.frmObj.Navigate(new AddEditPagq((sender as Button).DataContext as Group));
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        // Добавление пользователей
        {
            ClassFrame.frmObj.Navigate(new AddEditPagq(null)/*((Person)DGridUsers.SelectedItem)*/);
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            //Удаление нескольких пользователей
            var personForRemoving = DGridUsers.SelectedItems.Cast<Group>().ToList();
            if (MessageBox.Show($"Удалить {personForRemoving.Count()} пользователей?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    universityEntities.GetContext().Group.RemoveRange(personForRemoving);
                    universityEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены");
                    DGridUsers.ItemsSource = universityEntities.GetContext().Group.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {//Динамиеское отображение добавленных или изменённых данных
            if (Visibility == Visibility.Visible)
            {
                universityEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridUsers.ItemsSource = universityEntities.GetContext().Group.ToList();
            }
        }
        private void BtnResetAll_Click(object sender, RoutedEventArgs e)
        {
            DGridUsers.ItemsSource = universityEntities.GetContext().Group.ToList();
        }

        private void CmbFiltrGroup_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int id = Convert.ToInt32(CmbFiltrGroup.SelectedValue);
             DGridUsers.ItemsSource = universityEntities.GetContext().Group.Where(x => x.KodGroup == id).ToList();
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DGridUsers.ItemsSource = universityEntities.GetContext().Group.OrderBy(x => x.Group1).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DGridUsers.ItemsSource = universityEntities.GetContext().Group.OrderByDescending(x => x.Group1).ToList();
        }

        private void CmbFiltr_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbFiltr.SelectedIndex == 0)
            {
                DGridUsers.ItemsSource = universityEntities.GetContext().Group.Where(x => x.Group1 == "ИСП.20А").ToList();
            }
            else
                            if (CmbFiltr.SelectedIndex == 1)
            {
                DGridUsers.ItemsSource = universityEntities.GetContext().Group.Where(x => x.Group1 == "ССА19").ToList();
            }
            else
                            if (CmbFiltr.SelectedIndex == 2)
            {
                DGridUsers.ItemsSource = universityEntities.GetContext().Group.Where(x => x.Group1 == "ТМ20А").ToList();
            }
            else
                            if (CmbFiltr.SelectedIndex == 3)
            {
                DGridUsers.ItemsSource = universityEntities.GetContext().Group.Where(x => x.Group1 == "ОПУТ20").ToList();
            }
            else
                            if (CmbFiltr.SelectedIndex == 4)
            {
                DGridUsers.ItemsSource = universityEntities.GetContext().Group.Where(x => x.Group1 == "ИСП.21А").ToList();
            }
        }

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            DGridUsers.ItemsSource = universityEntities.GetContext().Group.Where(x => x.Para.ToLower().Contains(TxtSearch.Text.ToLower())).ToList();
        }

        private void BtnToList_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageListUser ());
        }
        private void BtnExcel_Click(object sender, RoutedEventArgs e)
        {


            //объект Excel
            var app = new Excel.Application();

            //книга 
            Excel.Workbook wb = app.Workbooks.Add();
            //лист
            Excel.Worksheet worksheet = app.Worksheets.Item[1];
            int indexRows = 1;
            //ячейка
            worksheet.Cells[1][indexRows] = "Группа";
            worksheet.Cells[2][indexRows] = "Пара";
            worksheet.Cells[3][indexRows] = "Дата";
            worksheet.Cells[4][indexRows] = "Номер аудитории";
            var printItems = universityEntities.GetContext().Group.ToList();
            //цикл по данным из таблицы
            foreach (var item in printItems)
            {
                worksheet.Cells[1][indexRows + 1] = indexRows;
                worksheet.Cells[2][indexRows + 1] = item.Group1;
                worksheet.Cells[3][indexRows + 1] = item.Para;
                worksheet.Cells[4][indexRows + 1] = item.Date;
                worksheet.Cells[5][indexRows + 1] = item.NumberAudit;
                
                indexRows++;
                //Excel.Range sumRange = worksheet.Range[worksheet.Cells[10][indexRows]];
                //sumRange.Merge();
                //sumRange.Value = "Итого:";
                //sumRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignRight;
                //worksheet.Cells[10][indexRows + 1].Formula = $"="
            }


            //показать Excel
            app.Visible = true;

        }
    }
}

